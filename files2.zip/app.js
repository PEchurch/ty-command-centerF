// ═══════════════════════════════════════════════
//  TY WILSON COMMAND CENTER — app.js
//  Live integrations: Google Calendar + Gmail
// ═══════════════════════════════════════════════

// ── Navigation ──
function show(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const panel = document.getElementById('panel-' + id);
  if (panel) panel.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => {
    if (n.getAttribute('onclick') && n.getAttribute('onclick').includes("'" + id + "'"))
      n.classList.add('active');
  });
  window.scrollTo(0, 0);
}

const agentNames = {
  '314':'Agent STAGE','pec':'Agent LIGHT','cbihp':'Agent LEGACY',
  'bfm':'Agent ROOTS','blkfthr':'Agent SIGNAL','apx':'Agent APEX'
};

function setComp(org, type) {
  const oEl = document.getElementById('c-org');
  const tEl = document.getElementById('c-type');
  if (oEl) { oEl.value = org; updateBadge(); }
  if (tEl && type) tEl.value = type;
}

function updateBadge() {
  const v = document.getElementById('c-org').value;
  document.getElementById('c-badge').textContent = v ? '→ Routing to: ' + agentNames[v] : '';
}

// ── System prompts per org ──
const systemPrompts = {
  '314': `You are Agent STAGE for 3.14 Entertainment Group — a full-service entertainment company covering music, film, fashion, culture, TV, books, marketing, advertising, and branding. Voice: bold, culturally sharp, commercially savvy. Write entertainment industry content at a high professional level.`,
  'pec': `You are Agent LIGHT for Positive Energy Church, led by Minister Ty Wilson in Tahlequah, Oklahoma. The church is growing online. Focus is NOT traditional sermons — it is positive quotes, daily affirmations, and uplifting content that spreads positive energy. The church also hosts 3 annual concert events. Voice: warm, uplifting, positive, welcoming. For booking content, be professional and persuasive.`,
  'cbihp': `You are Agent LEGACY for the Cherokees for Black Indian History Preservation Foundation (CBIHP) — a Cherokee organization that preserves the Native American narrative by including the stories of Black Native Americans to tell the complete history. Led by Cherokee citizen and historian Ty "GWY" Wilson. Voice: academic, historically rigorous, authoritative.

MANDATORY TERMINOLOGY — apply these precisely by time period:
- "Black Cherokee" (always capitalized) = UMBRELLA TERM for any person of Cherokee Nation membership or community who also has Black American lineage. Use at any point in history.
- PRE-CIVIL WAR: "Cherokee slaves" or "enslaved people in the Cherokee Nation" for those in bondage. "Free Black Cherokees" or "free Blacks in the Cherokee Nation" for those not enslaved. NEVER call free Blacks slaves. Both groups are still Black Cherokees.
- POST-TREATY OF 1866: "Cherokee Freedmen" = the specific historical generation freed from slavery by the Treaty of 1866. Used in research to mark social-political placement. After 1866 all received Cherokee citizenship and remained Black Cherokees.
- DESCENDANTS (living today): "Cherokee Freedmen descendants" or "descendants of Cherokee Freedmen." Inherited citizenship via the Dawes Freedmen line. There are NO living Cherokee Freedmen today.
- DAWES ROLLS: Many enrollees were intermarried and had NOT been slaves. Their Cherokee blood lineage was not recognized. Most descendants carry Cherokee AND European blood from slavery in the US, Cherokee Nation, or both. The assumption that they lack Cherokee blood is a documented historical misunderstanding — address when relevant.
- "by blood" — always in quotes, lowercase, first use per chapter.
- No m-dashes in prose. State uncertainty explicitly. Use only verifiable historical information.`,
  'bfm': `You are Agent ROOTS for BFM Inc., a nonprofit preserving the Native American narrative through the arts. Voice: culturally respectful, arts-forward, community-centered. Assist with books, documentary scripts, grant writing, and arts content related to Native American history and storytelling.`,
  'blkfthr': `You are Agent SIGNAL for BLK-FTHR Media's marketing department. Voice: creative, brand-strategic, results-oriented, platform-savvy. Write ad copy, campaigns, social captions, video scripts, and marketing content.`,
  'apx': `You are Agent APEX for Apexum, a peptide marketing and sales company. Voice: confident, health-forward, educational, trust-building. Educate prospects about peptides, build trust, and move them toward a consultation and purchase. All health claims must be responsible and not make unsubstantiated medical promises. Focus on education, potential benefits with appropriate qualifiers, and lifestyle outcomes.`
};

// ── Core AI call ──
async function callAI(systemPrompt, userPrompt, outputEl, labelEl) {
  const out = document.getElementById(outputEl);
  const lbl = document.getElementById(labelEl);
  out.className = 'output-box show';
  lbl.className = 'output-label show';
  out.innerHTML = '<span class="loading">⚡ Agent working...</span>';
  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }]
      })
    });
    const data = await resp.json();
    const text = data.content?.find(b => b.type === 'text')?.text || 'No output generated.';
    out.textContent = text;
    return text;
  } catch (e) {
    out.textContent = 'Error connecting to AI. Please try again.';
    return null;
  }
}

// ── Composer ──
async function generateContent() {
  const org = document.getElementById('c-org').value;
  const type = document.getElementById('c-type').value;
  const audience = document.getElementById('c-audience').value;
  const tone = document.getElementById('c-tone').value;
  const brief = document.getElementById('c-brief').value;
  if (!org || !type || !brief) { alert('Select an organization, content type, and fill in the brief.'); return; }
  const sys = systemPrompts[org] || 'You are a professional content writer.';
  const prompt = `Content type: ${type}\nAudience: ${audience || 'general'}\nTone: ${tone}\nBrief: ${brief}\n\nWrite this content fully, professionally, and ready to use.`;
  await callAI(sys, prompt, 'c-output', 'c-out-label');
}

function clearComp() {
  ['c-org','c-type','c-audience','c-brief'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  document.getElementById('c-tone').value = 'professional';
  document.getElementById('c-output').className = 'output-box';
  document.getElementById('c-out-label').className = 'output-label';
  document.getElementById('c-badge').textContent = '';
}

// ── Email — generate + Gmail draft ──
let lastEmailSubject = '';
let lastEmailBody = '';
let lastEmailTo = '';

async function generateEmail() {
  const org = document.getElementById('e-org').value;
  const type = document.getElementById('e-type').value;
  const toEmail = document.getElementById('e-to').value;
  const toName = document.getElementById('e-to-name').value;
  const subj = document.getElementById('e-subj').value;
  const brief = document.getElementById('e-brief').value;
  if (!brief) { alert('Please describe what the email should accomplish.'); return; }

  const orgNames = {'314':'3.14 Entertainment Group','pec':'Positive Energy Church','cbihp':'CBIHP Foundation','bfm':'BFM Nonprofit','blkfthr':'BLK-FTHR Media','apx':'Apexum'};
  const sys = systemPrompts[org];
  const prompt = `Write a complete ${type} email from ${orgNames[org]}.\nTo: ${toName || toEmail || 'recipient'}\nSubject hint: ${subj || 'write a compelling subject line'}\nGoal / Key points: ${brief}\n\nFormat EXACTLY as:\nSUBJECT: [subject line here]\n\n[full email body with greeting and professional sign-off]\n\nMake it ready to send.`;

  const result = await callAI(sys, prompt, 'e-output', 'e-out-label');

  if (result) {
    // Parse subject and body
    const lines = result.split('\n');
    const subjLine = lines.find(l => l.startsWith('SUBJECT:'));
    lastEmailSubject = subjLine ? subjLine.replace('SUBJECT:', '').trim() : (subj || 'Email from ' + orgNames[org]);
    lastEmailBody = result;
    lastEmailTo = toEmail;

    // Show Gmail draft button
    const draftBtn = document.getElementById('e-draft-btn');
    if (draftBtn) {
      draftBtn.style.display = 'inline-block';
      document.getElementById('e-gmail-confirm').style.display = 'none';
    }
  }
}

// Called from Claude (outside artifact) — saves to Gmail drafts
function sendToGmail() {
  // Signal to the parent Claude session
  if (window.parent && window.parent.sendPrompt) {
    window.parent.sendPrompt(`Save this as a Gmail draft. Subject: "${lastEmailSubject}". To: ${lastEmailTo || 'no recipient specified'}. Body:\n\n${lastEmailBody}`);
  } else {
    // Fallback: copy to clipboard and instruct
    navigator.clipboard.writeText(lastEmailBody).then(() => {
      const conf = document.getElementById('e-gmail-confirm');
      conf.textContent = '📋 Email copied to clipboard. Paste it into Gmail to send. Or ask Claude in the chat to "save this email as a Gmail draft to ' + (lastEmailTo || '[recipient]') + '".';
      conf.style.display = 'block';
    });
  }
}

// ── Schedule — conflict check + Google Calendar ──
let events = [];
let lastEvent = null;

const orgColors = {'314':'#e8a020','pec':'#34d399','cbihp':'#a78bfa','bfm':'#fb923c','blkfthr':'#f43f5e','apx':'#38bdf8','personal':'#6b7280'};
const orgShort = {'314':'3.14','pec':'PEC','cbihp':'CBIHP','bfm':'BFM','blkfthr':'BLK-F','apx':'APX','personal':'PERS'};
const orgCalColors = {'314':'5','pec':'10','cbihp':'9','bfm':'6','blkfthr':'11','apx':'7','personal':'8'};

function addEvent() {
  const date = document.getElementById('s-date').value;
  const time = document.getElementById('s-time').value;
  const endTime = document.getElementById('s-end-time').value;
  const name = document.getElementById('s-name').value || 'New Event';
  const notes = document.getElementById('s-notes').value;
  const org = document.getElementById('s-org').value;
  const type = document.getElementById('s-type').value;
  if (!date) { alert('Please select a date.'); return; }

  const conflict = events.find(e => e.date === date && e.time && e.time === time && time !== '');
  const alertEl = document.getElementById('s-alert');
  const gcalBtn = document.getElementById('s-gcal-btn');
  const gcalConf = document.getElementById('s-gcal-confirm');

  if (conflict) {
    alertEl.innerHTML = `<div class="conflict-alert conflict-warn">⚠️ Conflict: "${conflict.name}" (${orgShort[conflict.org]}) is already scheduled at this time. Choose a different time.</div>`;
    if (gcalBtn) gcalBtn.style.display = 'none';
  } else {
    lastEvent = { date, time, endTime, name, notes, org, type };
    events.push(lastEvent);
    alertEl.innerHTML = `<div class="conflict-alert conflict-ok">✅ No conflicts — "${name}" is clear. Click "Add to Google Calendar" to save it live.</div>`;
    document.getElementById('event-count').textContent = events.length;
    if (gcalBtn) gcalBtn.style.display = 'inline-block';
    if (gcalConf) gcalConf.style.display = 'none';
    renderEvents();
  }
}

function addToGoogleCalendar() {
  if (!lastEvent) return;
  const { date, time, endTime, name, notes, org, type } = lastEvent;
  const orgFullNames = {'314':'3.14 Entertainment Group','pec':'Positive Energy Church','cbihp':'CBIHP Foundation','bfm':'BFM Nonprofit','blkfthr':'BLK-FTHR Media','apx':'Apexum','personal':'Personal'};

  const startISO = time ? `${date}T${time}:00` : date;
  const endISO = endTime ? `${date}T${endTime}:00` : (time ? `${date}T${time.split(':')[0]}:59:00` : date);
  const desc = `Organization: ${orgFullNames[org]}\nType: ${type}${notes ? '\nNotes: ' + notes : ''}`;
  const colorId = orgCalColors[org] || '1';

  // Signal Claude to create the event
  const msg = `Create a Google Calendar event with these details:\n- Title: "${name}"\n- Start: ${startISO}\n- End: ${endISO}\n- Description: ${desc}\n- Color ID: ${colorId}\n- Timezone: America/Chicago`;

  if (window.parent && window.parent.sendPrompt) {
    window.parent.sendPrompt(msg);
  } else {
    // Show instruction for Claude chat
    const conf = document.getElementById('s-gcal-confirm');
    conf.textContent = `📅 Copy this to Claude chat to add to Google Calendar: "${msg}"`;
    conf.style.display = 'block';
  }

  const conf = document.getElementById('s-gcal-confirm');
  if (conf) {
    conf.textContent = `🗓️ Request sent to Claude — "${name}" is being added to Google Calendar now.`;
    conf.style.display = 'block';
  }
  document.getElementById('s-gcal-btn').style.display = 'none';
}

function renderEvents() {
  const list = document.getElementById('events-list');
  if (!list) return;
  if (!events.length) { list.innerHTML = '<div style="color:var(--muted);font-size:0.82rem;padding:14px;">No events yet.</div>'; return; }
  const sorted = [...events].sort((a, b) => a.date.localeCompare(b.date));
  list.innerHTML = sorted.map(e => `
    <div class="event-row">
      <span class="event-org-tag" style="background:${orgColors[e.org]}22;color:${orgColors[e.org]};border:1px solid ${orgColors[e.org]}44">${orgShort[e.org]}</span>
      <span class="event-name">${e.name}</span>
      <span class="event-meta">${e.date}${e.time ? ' · ' + e.time : ''}${e.endTime ? ' – ' + e.endTime : ''}</span>
      <span class="event-meta">[${e.type}]</span>
    </div>`).join('');
}

// ── Media ──
async function generateMedia() {
  const org = document.getElementById('m-org').value;
  const format = document.getElementById('m-format').value;
  const topic = document.getElementById('m-topic').value;
  const cta = document.getElementById('m-cta').value;
  const brief = document.getElementById('m-brief').value;
  if (!topic) { alert('Please enter a topic or subject.'); return; }
  const sys = systemPrompts[org];
  const prompt = `Create ${format} content.\nTopic: ${topic}\nCall to action: ${cta || 'engage'}\nNotes: ${brief || 'none'}\n\nDeliver complete, ready-to-use content with all elements (caption, hashtags, script lines, or brief as appropriate).`;
  await callAI(sys, prompt, 'm-output', 'm-out-label');
}

// ── Book copy ──
async function generateBookCopy() {
  const title = document.getElementById('bk-title').value;
  const type = document.getElementById('bk-type').value;
  const brief = document.getElementById('bk-brief').value;
  if (!brief) { alert('Please fill in the details.'); return; }
  const prompt = `Write ${type} content for the book "${title || 'untitled'}".\nDetails: ${brief}\n\nWrite it fully, professionally, and ready to use in the book.`;
  await callAI(systemPrompts['blkfthr'], prompt, 'bk-output', 'bk-out-label');
}

// ── Audio adapt ──
async function adaptForAudio() {
  const text = document.getElementById('au-text').value;
  if (!text) { alert('Please paste a passage from your manuscript.'); return; }
  const prompt = `Adapt this manuscript passage for audio narration. Make it flow naturally when read aloud. Remove visual formatting (tables, footnotes become readable sentences). Add [PAUSE] markers where appropriate. Preserve meaning exactly.\n\n${text}`;
  await callAI('You are an audiobook production specialist who adapts written manuscripts for audio narration.', prompt, 'au-output', 'au-out-label');
}

// ── Apexum ──
async function generateApexum() {
  const type = document.getElementById('apx-type').value;
  const topic = document.getElementById('apx-topic').value;
  const brief = document.getElementById('apx-brief').value;
  const prompt = `Create ${type} content for Apexum.\nPeptide / Topic: ${topic || 'general peptides'}\nSpecifics: ${brief || 'general approach'}\n\nWrite complete, ready-to-use content.`;
  await callAI(systemPrompts['apx'], prompt, 'apx-output', 'apx-out-label');
}
